## Uses Dungeondraft v1.1.0.0
##
## Path2Water v1.0.0
## Author: Avery Berg
## 
## Allows the user to snap selected paths to waterlines
##

# Required Global
var script_class = "tool"

# External Scripts
var utils = null

# Globals
var select_tool = null
var path2water_button = null
var dropdown_menu = null

var flip_button = null

var prev_size = 0


func get_selected_items():
    ##
    ## Get the selected items
    ##
    var select_tool = Global.Editor.Tools["SelectTool"]
    var selected_items = select_tool.Selected
    
    return selected_items


func get_paths():
    ##
    ## Get all the path nodes
    ##
    var cur_level = Global.World.levels[Global.World.CurrentLevelId]
    return cur_level.Pathways.get_children()


func get_selected_path():
    ##
    ## Get the selected path
    ##
    var paths = get_paths()

    for item in get_selected_items():
        if item in paths:
            return item
    
    return null


func get_water_lines():
    ##
    ## Get the water lines
    ##
    var cur_level = Global.World.levels[Global.World.CurrentLevelId]
    var water_mesh = cur_level.WaterMesh
    return water_mesh.Lines


func path2waterline(path, surface_index):
    ##
    ## Align a path with a water line
    ##
    var water_lines = get_water_lines()

    if surface_index >= water_lines.size():
        return
    
    var water_line = water_lines[surface_index]

    path.loop = true
    path.SetEditPoints(water_line.get_points())

    path.Save()


func on_clicked_path2water_button():
    ##
    ## Callback function for clicking the path2water button
    ##
    var index = dropdown_menu.get_selected_id()
    var path = get_selected_path()
    if not path:
        return
    
    path2waterline(path, index)



func on_clicked_flip_button():
    ##
    ## Callback function for clicking the flip button
    ##
    var path = get_selected_path()
    if not path:
        return
    # var points = path.get_points()
    # points.invert()
    # path.SetEditPoints(points)
    # path.Save()


func on_select_preset_target(index):
    print("selected target")


func can_use_tool():
    ##
    ## Determine whether the tool is usable for the current selection
    ##
    if get_selected_items().size() != 1:
        # print("Nothing selected")
        return false
    
    var path = get_selected_path()
    if not path:
        # print("No path selected")
        return false

    # print("Can use tool")
    return true


func update(delta):
    ##
    ## Called once per tick
    ##

    if select_tool == Global.Editor.ActiveTool:
        var do_show = can_use_tool()
        path2water_button.visible = do_show
        dropdown_menu.get_parent().visible = do_show

        # Update the dropdown menu list
        var cur_size = get_water_lines().size()
        # print("Cur size: " + str(cur_size))
        if cur_size != prev_size:
            dropdown_menu.clear()
            for i in range(cur_size):
                dropdown_menu.add_item(i)

        prev_size = cur_size



func start():
    ##
    ## Initialize the mod
    ## Called immediately after the script is loaded
    ##

    # Load any external scripts
    utils = load(Global.Root + "scripts/utils.gd").new()

    select_tool = Global.Editor.Tools["SelectTool"]
    var tool_panel = Global.Editor.Toolset.GetToolPanel("SelectTool")

    var panel_length = tool_panel.get_children()[-1].get_children().size()

    # Create and add the path2water button
    path2water_button = tool_panel.CreateButton("path 2 water", Global.Root + "icons/ditto.png")
    path2water_button.connect("pressed", self, "on_clicked_path2water_button")
    tool_panel.Align.move_child(path2water_button, panel_length-4)

    dropdown_menu = tool_panel.CreateLabeledDropdownMenu("on_select_target", "Water Line", ["0"], "0")
    tool_panel.Align.move_child(tool_panel.get_children()[-1].get_children()[-1], panel_length-4)

    # Create the flip button
    # flip_button = tool_panel.CreateButton("Flip", Global.Root + "icons/ditto.png")
    # flip_button.connect("pressed", self, "on_clicked_flip_button")
    # tool_panel.Align.move_child(flip_button, panel_length-4)

