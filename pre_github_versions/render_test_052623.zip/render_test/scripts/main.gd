## Uses Dungeondraft v1.1.0.0
##
## Toggle Layers v1.0.0
## Author: Avery Berg
## Allows developers to render the map programatically
## 
## TODO: Description
##

# Required Globals
var script_class = "tool"

# External Scripts
var utils = null
var Renderer
var Render

var renderer = null

var tool_panel = null
var render_tool = null

var is_cursor_set = false

var rendered_water_img = null
var rendered_water_mask = null

var layer_map = {
  -500: "Terrain",
  -400: "Below Ground",
  -300: "Caves",
  -200: "Floor",
  -100: "Below Water",
  0: "Water",
  100: "User Layer 1",
  200: "User Layer 2",
  300: "User Layer 3",
  400: "User Layer 4",
  500: "Portals",
  600: "Walls",
  700: "Above Walls",
  800: "Roofs",
  900: "Above Roofs",
  9999: "Lights"
}

func print_args(arg1=null, arg2=null, arg3=null, arg4=null):
    var args = [arg1, arg2, arg3, arg4]
    print('args: ' + str(args))


func layer_has_content(z_index):
    # print('Setting layer ' + str(z_index) + ' to ' + str(visible))
    var level = Global.World.GetLevelByID(Global.World.CurrentLevelId)

    # Check water
    # TODO: Figure this out later
    if z_index == 0:
        return true
    
    # Check terrain
    if z_index == -500:
        return true

    # Check objects
    for obj in level.Objects.get_children():
        if obj.z_index == z_index:
            return true
    
    # Check paths
    for path in level.Pathways.get_children():
        if path.z_index == z_index:
            return true
    
    # Check pattern shapes
    for layer in level.PatternShapes.get_children():
        if layer.z_index == z_index:
            if layer.get_children().size():
                return true
            break
    
    # Check roofs
    if z_index == 800 and level.Roofs.get_children().size():
        return true
    
    # Check lights
    if z_index == 9999 and level.Lights.get_children().size():
        return true
    
    # Check portals
    if z_index == 500 and level.Portals.get_children().size():
        return true
    
    return false


func set_layer_visibility(z_index, visible):
    # print('Setting layer ' + str(z_index) + ' to ' + str(visible))
    var level = Global.World.GetLevelByID(Global.World.CurrentLevelId)

    # Toggle objects
    for obj in level.Objects.get_children():
        if obj.z_index == z_index:
            obj.visible= visible
    
    # Toggle paths
    for path in level.Pathways.get_children():
        if path.z_index == z_index:
            path.visible = visible
    
    # Toggle pattern shapes
    for layer in level.PatternShapes.get_children():
        if layer.z_index != z_index:
            continue
        for pattern_shape in layer.get_children():
            pattern_shape.visible = visible
    
    # Toggle roofs
    if z_index == 800:
        for roof in level.Roofs.get_children():
            roof.visible = visible
    
    # Toggle lights
    if z_index == 9999:
        for light in level.Lights.get_children():
            light.visible = visible
    
    # Toggle portals
    if z_index == 500:
        for portal in level.Portals.get_children():
            portal.visible = visible
    
    # Toggle water
    if z_index == 0:
        level.WaterMesh.visible = visible
    
    # Toggle terrain
    if z_index == -500:
        level.Terrain.visible = visible


func set_grid_visibility(visible):
    Global.World.get_GridMesh().visible = visible


func set_viewport_transparency(is_transparent):
    # var is_transparent = !visible

    # Get the viewports
    var viewport = Global.Editor.get_viewport()
    var viewport_b = Global.Editor.owner.get_Viewport()
    
    # Make the viewport transparent
    viewport.transparent_bg = is_transparent
    viewport_b.transparent_bg = is_transparent

    # Hide the terrain and water
    # var level = Global.World.GetLevelByID(Global.World.CurrentLevelId)
    # level.Terrain.visible = visible
    # level.WaterMesh.visible = visible


func show_only(z_indices):
    # Ensure z_indices is a list
    if not typeof(z_indices) == 19:
        z_indices = [z_indices]
    
    for layer_index in layer_map.keys():
        set_layer_visibility(layer_index, layer_index in z_indices)
    
    set_grid_visibility(false)

    set_viewport_transparency(true)


func show_all():
    for z_index in layer_map.keys():
        set_layer_visibility(z_index, true)

    set_viewport_transparency(false)


func on_layer_render_scan(delta, z_index):
    show_only(z_index)


func on_layer_render_finish(rendered_img):
    show_all()


func on_water_terrain_render_finish(water_terrain_img, water_mask_img):
    show_all()

    var dest_path = '/Users/Avery/Documents/Dungeondraft/Renders/dd_render_water.png'

    var water_img = null
    var image_size = water_terrain_img.get_size()
    var image_rect = Rect2(0, 0, image_size.x, image_size.y)
    
    # Create the water image
    water_img = Image.new()
    water_img.create(image_size.x, image_size.y, false, Image.FORMAT_RGBA8)

    # Apply the water mask to the water terrain and store it in the water image
    water_img.blit_rect_mask(water_terrain_img, water_mask_img, image_rect, Vector2(0, 0))

    # Add the water image to the export queue
    renderer.export_image(water_img, dest_path)


func on_water_render_mask_finish(water_mask_img):
    show_all()

    var water_terrain_render = Render.new(self)
    water_terrain_render.connect('scanning', self, 'on_layer_render_scan', [[0, -500]])
    water_terrain_render.connect('scan_finished', self, 'on_water_terrain_render_finish', [water_mask_img])
    renderer.submit(water_terrain_render)


func _on_reload():
    print(' ')

    var render_folder = '/Users/Avery/Documents/Dungeondraft/Renders'

    for z_index in layer_map.keys():
        if not layer_has_content(z_index):
            continue
        
        var dest_path = render_folder + '/dd_render_' + str(z_index) + '.png'
        var new_render = Render.new(self, dest_path)
        new_render.connect('scanning', self, 'on_layer_render_scan', [z_index])
        new_render.connect('scan_finished', self, 'on_layer_render_finish')
        renderer.submit(new_render)
    
    # Create and submit a render for the water
    var water_mask_render = Render.new(self)
    water_mask_render.connect('scanning', self, 'on_layer_render_scan', [0])
    water_mask_render.connect('scan_finished', self, 'on_water_render_mask_finish')
    renderer.submit(water_mask_render)

    return


func update(delta):
    ##
    ## Called once per tick
    ##
    if renderer:
        renderer.tick(delta)
    
    if Global.Editor.ActiveTool == render_tool:

        # Ensure that the cursor is hidden for the render tool
        if not is_cursor_set:
            Global.World.get_node('WorldUI').set_CursorMode(0)
            is_cursor_set = true
    
    

func start():
    ##
    ## Initialize the mod
    ## Called immediately after the script is loaded
    ##

    # Load any external scripts
    print('Loading utils')
    utils = load(Global.Root + "scripts/utils.gd").new()

    print('Loading Renderer')
    Renderer = load(Global.Root + 'scripts/renderer.gd').new().Renderer

    print('Loading Render')
    Render = load(Global.Root + 'scripts/render.gd').new().Render

    print('Creating Renderer instance')
    renderer = Renderer.new(self)
    print('Created Renderer instance')

    # Add reload callback
    var reload_mods_button = Global.Editor.get_node("VPartition/MenuBar/MenuAlign/ReloadModsButton")
    reload_mods_button.connect("pressed", self, "_on_reload")

    # Create the new tool
    var category = "Settings"
    var id = "render_test"
    var name = "Render Test"
    var icon = Global.Root + "icons/render_test.png"

    tool_panel = Global.Editor.Toolset.CreateModTool(self, category, id, name, icon)
    tool_panel.CreateLabel("Render Test")
    render_tool = tool_panel.Tool
    # tool_panel.CreateLabel("Objects")

    