## Uses Dungeondraft v1.1.0.0
##
## Scatter Plus v1.0.0
## Author: Avery Berg
## 
## Adds additional functionality to the scatter tool
##

# Required Global
var script_class = "tool"

# External Scripts
var utils = null

# Globals
var scatter_tool = null
var follow_checkbox = null
var in_follow_mode = false
var prev_mouse_pos = null
var on_icon = null
var off_icon = null


func on_follow_checkbox_click():
    ##
    ## Callback function for clicking the follow stroke checkbox button
    ##
    in_follow_mode = !in_follow_mode

    # Set the group_checkbox icon
    if in_follow_mode:
        follow_checkbox.icon = on_icon
    else:
        follow_checkbox.icon = off_icon

    if not in_follow_mode and scatter_tool.Preview:
        scatter_tool.Preview.set_rotation(0)
    
    # print(utils.dir_string(scatter_tool))
    # print(scatter_tool.get_signal_list())
    # scatter_tool.Next(true)
    # print(scatter_tool.get_Spread())
    # print(utils.dir_string(scatter_tool, 'spread'))
    
    # TESTING DELETE LATER
    # if Script.GetAssetList():
    #     print(utils.dir_string(Script.GetAssetList().get_script().CSharpScript))
    # else:
    #     print("No asset list")
    # print()
    # print(utils.dir_string(Script))
    # print(get_script().source_code)
    # var prop = Prop.new()
    # print(prop)
    # print(" ")
    # var test_node = Global.Editor.get_Draw()
    # # print(utils.dir_string(scatter_tool))
    # if test_node and typeof(test_node) == 17:
    #     for line in utils.dir_string(Global.Editor).split('\n'):
    #         if line != line.to_lower():
    #             print(line)
    # else:
    #     print("Can't get dir_string")
    
    # print(Global.Editor.Tools["ObjectTool"].get_signal_list())
    # print("---" + str(test_node) + "---")
    # print(Global.Editor == test_node)
    print(" ")

    

    # -------------------NOTES-------------------
    # TODO: 
    #   Create a replica "Spread" slider.
    #   Hide the original spread slider.
    #   Manipulate the original spread slider to fix
    #   distance discrepencies from rotation when using
    #   the follow_stroke mode.
    # 
    # First need to figure out how to get the horizontal
    # and vertical bounding boxes based on transparency
    # of the Preview's texture.
    # Then those can be used for spread calculations.
    # -------------------------------------------
    
    # print()
    # print(utils.dir_string(scatter_tool.get_script()))

    # CSharpScript
    # Reference
    # Resource
    # Resource
    # Script
    # resource_local_to_scene
    # resource_name
    # resource_path
    # script/source
    # source_code


func start():
    ##
    ## Initialize the mod
    ## Called immediately after the script is loaded
    ##

    # Load any external scripts
    utils = load(Global.Root + "scripts/utils.gd").new()

    # Cache the scatter tool to make it easier to reference in this script
    scatter_tool = Global.Editor.Tools["ScatterTool"]

    var tool_panel = Global.Editor.Toolset.GetToolPanel("ScatterTool")
    on_icon = utils.load_tx(Global.Root + "icons/on.png")
    off_icon = utils.load_tx(Global.Root + "icons/off.png")

    var panel_length = tool_panel.get_children()[-1].get_children().size()

    # Create and add the "Follow Stroke" checkbox button
    follow_checkbox = tool_panel.CreateButton("Follow Stroke", Global.Root + "icons/off.png")
    follow_checkbox.connect("pressed", self, "on_follow_checkbox_click")
    tool_panel.Align.move_child(follow_checkbox, panel_length-12)


func update(delta):
    ##
    ## Called once per tick
    ##
    var selected_items = Global.Editor.Tools["SelectTool"].Selected
    
    # if selected_items:
    #     var prop_script = selected_items[0].get_script()
    #     print(prop_script.Reference)
    #     print(prop_script.Resource)
    #     print(prop_script.resource_local_to_scene)
    #     print(prop_script.resource_name)
        # print(utils.dir_string(selected_items[0].get_script()))
        # print(selected_items[0].get_script().resource_path)
        # print("hello")
        # print(utils.dir_string(selected_items[0]))

    # CSharpScript
    # Reference
    # Resource
    # Resource
    # Script
    # resource_local_to_scene
    # resource_name
    # resource_path
    # script/source
    # source_code

    if scatter_tool != Global.Editor.ActiveTool or not in_follow_mode:
        return

    var mouse_pos = Global.World.get_global_mouse_position()

    if prev_mouse_pos != null and prev_mouse_pos != mouse_pos:
        var rad_angle = prev_mouse_pos.angle_to_point(mouse_pos)

        var const_spread = 0.25
        
        # if scatter_tool.Preview:
        #     if rad_angle > 0.785398 or rad_angle < 5.49779:
        #         scatter_tool.get_Spread().set_value(const_spread/2.0)
        #     elif rad_angle < 2.35619 and rad_angle > 3.92699:
        #         scatter_tool.get_Spread().set_value(const_spread/2.0)
        #     else:
        #         scatter_tool.get_Spread().set_value(const_spread)
        
        # Rotate additionally by 90 degrees
        rad_angle += 1.5707963

        # Normalize the angle
        rad_angle = fmod(rad_angle, 6.2831853)
        if rad_angle < 0:
            rad_angle += 6.2831853

        if scatter_tool.Preview:
            # print(rad_angle)
            # scatter_tool.Preview.set_rotation(rad_angle)
            scatter_tool.Preview.set_rotation(rad_angle)
            
            # if (3.92699 < rad_angle and rad_angle < 5.49779) or (0.785398 < rad_angle and rad_angle < 2.35619):
            #     var sprite_size = scatter_tool.Preview.get_Sprite().get_rect().size
            #     var new_spread = const_spread * float(sprite_size[1])/float(sprite_size[0])
            #     scatter_tool.get_Spread().set_value(new_spread)
            # else:
            #     scatter_tool.get_Spread().set_value(const_spread)
            
            # print(scatter_tool.get_Spread().get_value())
            
    
    prev_mouse_pos = mouse_pos
