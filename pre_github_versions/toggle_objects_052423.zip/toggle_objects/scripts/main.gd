## Uses Dungeondraft v1.1.0.0
##
## Toggle Layers v1.0.0
## Author: Avery Berg
## Uses functions from Layers Mod
## 
## TODO: Description
##

# Required Globals
var script_class = "tool"

# External Scripts
var utils = null
var qutils = null
var class_a = null

var elapsed_time = 0.0
var wave_frame = 0

var levels = []

var current_render = null

# Globals

class Render:
    var rendered_image = null
    var grid_ppi = 256
    var is_running = false
    var is_complete = false

    var _global = null
    var _viewport = null
    var _level = null

    var _world_size = null

    var _render_cam = null
    var _cam_zoom = null
    var _cam_size = null

    var _bucket_size = null
    var _bucket_rect = null
    var _h_bucket_count = null
    var _v_bucket_count = null

    var _i = 0
    var _j = 0

    func _init(global_ref, ppi=256):
        rendered_image = Image.new()
        grid_ppi = ppi
        is_running = false
        is_complete = false

        _global = global_ref
        print('Loaded global reference')
        print('_global: ' + str(_global))

        _viewport = _global.Editor.get_viewport()
        print('_viewport: ' + str(_viewport))

        _level = _global.World.get_Level()

        print('_level: ' + str(_level))
        # _main_ui_node = viewport.get_children()[-1].ViewportContainer2D.get_children()[0].get_children()[1]
        
        _world_size = _global.World.get_WorldRect().size
        print('_world_size: ' + str(_world_size))

        _render_cam = _viewport.get_children()[-1].get_Camera()

        print('_render_cam: ' + str(_render_cam))
        _cam_zoom = Vector2(256.0 / float(ppi), 256.0 / float(ppi))
        print('_cam_zoom: ' + str(_cam_zoom))
        _cam_size = _viewport.get_visible_rect().size
        print('_cam_size: ' + str(_cam_size))

        _bucket_size = _cam_size * _cam_zoom
        print('_bucket_size: ' + str(_bucket_size))
        _bucket_rect = Rect2(0, 0, _bucket_size.x, _bucket_size.y)
        print('_bucket_rect: ' + str(_bucket_rect))
        _h_bucket_count = ceil(_world_size.x / _bucket_size.x)
        print('_h_bucket_count: ' + str(_h_bucket_count))
        _v_bucket_count = ceil(_world_size.y / _bucket_size.y)
        print('_v_bucket_count: ' + str(_v_bucket_count))

        
        # print('_main_ui_node: ' + str(_main_ui_node))
        print('_world_size: ' + str(_world_size))
        print('_render_cam: ' + str(_render_cam))
        print('_cam_zoom: ' + str(_cam_zoom))
        print('_cam_size: ' + str(_cam_size))
        print('_bucket_size: ' + str(_bucket_size))
        print('_bucket_rect: ' + str(_bucket_rect))
        print('_h_bucket_count: ' + str(_h_bucket_count))
        print('_v_bucket_count: ' + str(_v_bucket_count))

        _i = 0
        _j = 0
    
    func save(file_path):
        if not is_complete:
            return
        print('Saving render')
        rendered_image.save_png(file_path)
        print('Render saved')
    
    func start():
        print('Starting render')
        is_running = true
        _global.Editor.get_node("VPartition").visible = false
        _global.Editor.get_node("Floatbar").visible = false

        # Set the initial position and zoom
        _render_cam.set_global_position(0.5 * _bucket_size)
        _render_cam.set_zoom(_cam_zoom)

        rendered_image.create(_bucket_size.x * _h_bucket_count, _bucket_size.y * _v_bucket_count, false, Image.FORMAT_RGBA8)
    
    func stop():
        print('Render complete')
        is_running = false
        is_complete = true
        _global.Editor.get_node("VPartition").visible = true
        _global.Editor.get_node("Floatbar").visible = true

        print('Cropping image')
        var final_resolution = _world_size / _cam_zoom
        rendered_image.crop(final_resolution.x, final_resolution.y)
        
        # _main_ui_node.FloorRT.get_children()[1].visible = true

    func step():
        print('Stepping')
        _render_bucket()
        _i += 1
        if _i >= _h_bucket_count:
            if _j >= _v_bucket_count:
                stop()
            else:
                _i = 0
                _j += 1
        
        # Set the position and zoom for the next bucket
        var next_bucket_pos = Vector2(_i+0.5, _j+0.5) * _bucket_size
        _render_cam.set_global_position(next_bucket_pos)
        _render_cam.set_zoom(_cam_zoom)
        print('Set camera position to ' + str(next_bucket_pos))
        print('Finished step')

    func _render_bucket():
        print('Rendering bucket')
        var bucket_origin = Vector2(_i, _j) * _bucket_size
        var bucket_pos = bucket_origin + (0.5 * _bucket_size)

        var bucket_render = _viewport.get_texture().get_data()
        bucket_render.convert(Image.FORMAT_RGBA8)
        bucket_render.flip_y()

        rendered_image.blit_rect(bucket_render, _bucket_rect, bucket_origin)

        print('Rendering at position: ' + str(bucket_pos))


func _on_reload():
    print(' ')
    elapsed_time = 0.0
    
    var level = Global.World.get_Level()

    var viewport = Global.Editor.get_viewport()
    var master = viewport.get_children()[-1]

    var tile_cam = level.FloorTileCamera
    var master_cam = master.get_Camera()

    var vp2d = master.ViewportContainer2D.get_children()[0]
    var main_node = vp2d.get_children()[1]

    var grid = main_node.get_children()[0]
    var bounds = main_node.get_children()[2]
    var level_ground = main_node.get_children()[4]

    # utils.print_ancestors(level.FloorRT)

    var print_children = false
    if print_children:
        for child in Global.Editor.get_children():
            print(str(child) + ': ' + str(child.visible))
    
    # Global.Editor.get_node("Floatbar").visible = true
    # vp2d.get_children()[1].visible = true


    # for line in utils.dir_string(level).split('\n'):
    #     if line.to_lower() != line:
    #         print(line)

    current_render = Render.new(Global)
    current_render.start()
    # print(current_render._render_cam)
    # print(master_cam)
    return

    # var level = Global.World.get_Level()

    # var viewport = Global.Editor.get_viewport()
    # var master = viewport.get_children()[-1]

    # var tile_cam = level.FloorTileCamera
    # var master_cam = master.get_Camera()
    # print(viewport.get_visible_rect().size)
    # print(master_cam.get_global_position())
    # print(tile_cam.get_global_position())
    # print(' ')
    var view_size = viewport.get_visible_rect().size
    var camera_pos = master_cam.global_transform.origin
    var camera_zoom = master_cam.zoom

    # print('Camera Pos: ' + str(master_cam.get_global_position()))
    # print('Camera Zoom: ' + str(master_cam.zoom))
    # print(' ')

    # level.FloorRT.get_children()[1].visible = true
    # print(utils.dir_string(master_cam, 'zoom'))
    # (8957.115234, 5125.5)
    # master_cam.set_zoom(Vector2(1.0, 1.0))
    # set_zoom
    # master_cam.set_global_position(Vector2(0.0, 0.0))

    # print(master_cam.get_screen_center_position())
    # main_node.visible = true
    # print()

    # Top left corner of map is 0, 0 in global coordinates
    # Size of a bucket: Global.World.get_viewport_rect().size
    # Center of camera: master_cam.get_global_position()
    # World Size: Global.World.get_WorldRect().size
    
    # Number of horizontal buckets = world_size.x / cam_size.x
    # Number of vertical buckets = world_size.y / cam_size.y
    # Starting position: Vector2(0.0, 0.0) + (0.5*cam_size)

    # Default Scale is 256 px = 1 grid square = 256 global units

    # var world_size = Global.World.get_WorldRect().size

    # master_cam.set_global_position(world_size)
    # var cam_size = viewport.get_visible_rect().size
    # var cam_zoom = master_cam.zoom
    
    # var bucket_size = cam_size * cam_zoom
    # var bucket_rect = Rect2(0, 0, bucket_size.x, bucket_size.y)

    # var h_bucket_count = ceil(world_size.x / bucket_size.x)
    # var v_bucket_count = ceil(world_size.y / bucket_size.y)

    # # var h_bucket_count = ceil(world_size.x / (cam_size.x * cam_zoom.x))
    # # var v_bucket_count = ceil(world_size.y / (cam_size.y * cam_zoom.y))
    # var render = Image.new()
    # render.create(bucket_size.x * h_bucket_count, bucket_size.y * v_bucket_count, false, Image.FORMAT_RGBA8)

    # main_node.visible = false

    # for i in range(0, h_bucket_count):
    #     # var x_pos = (i + 0.5) * cam_size.x * cam_zoom.x
    #     for j in range(0, v_bucket_count):
    #         var bucket_origin = Vector2(i, j) * bucket_size
    #         var bucket_pos = bucket_origin + (0.5 * bucket_origin)

    #         master_cam.set_global_position(bucket_pos)
            
    #         # var v_pos = (j + 0.5) * cam_size.y * cam_zoom.y
    #         # var bucket_pos = Vector2(i+0.5, j+0.5) * bucket_size

    #         var bucket_render = viewport.get_texture().get_data()
    #         bucket_render.convert(Image.FORMAT_RGBA8)
    #         # bucket_render.flip_y()

    #         render.blit_rect(bucket_render, bucket_rect, bucket_origin)

    #         print(bucket_pos)
    
    # main_node.visible = true

    # render.save_png("/Users/Avery/Desktop/dd_render.png")
    
    # print('Rendered the image')
    

    # var new_pos = Vector2(0.0, 0.0) + ((0.5 + i) * cam_size * cam_zoom)

    # master_cam.set_global_position(start_pos)


    # print(world_size-(0.5*cam_size))
    # print()

    # print(Global.World.get_viewport_rect().size)
    # print(Global.World.get_viewport_transform())
    # print(utils.dir_string(Global.World, 'view'))
    # print(viewport.global_transform.origin)
    # print(visible_rect)
    # print(viewport.get_visible_rect().size)
    # print(utils.dir_string(viewport, 'rec'))
    print(' ')
    # print('\n')


func update(delta):
    ##
    ## Called once per tick
    ##
    elapsed_time += delta

    if elapsed_time >= 0.2:
        # Global.Editor.get_node("VPartition").visible = true
        if current_render:
            if current_render.is_running:
                current_render.step()
            elif current_render.is_complete:
                current_render.save('/Users/Avery/Desktop/dd_render.png')
                current_render = null
        elapsed_time = 0.0
    

    # print(Global.World.get_global_mouse_position())


func start():
    ##
    ## Initialize the mod
    ## Called immediately after the script is loaded
    ##

    # Load any external scripts
    print("Loading utils")
    utils = load(Global.Root + "scripts/utils.gd").new()

    qutils = load(Global.Root + "scripts/utils.gd").new()
    qutils.init(self)

    # Add reload callback
    var reload_mods_button = Global.Editor.get_node("VPartition/MenuBar/MenuAlign/ReloadModsButton")
    reload_mods_button.connect("pressed", self, "_on_reload")

    # Create the new tool
    var category = "Settings"
    var id = "toggle_objects"
    var name = "Toggle Objects"
    var icon = Global.Root + "icons/toggle_layers.png"

    var tool_panel = Global.Editor.Toolset.CreateModTool(self, category, id, name, icon)
    tool_panel.CreateLabel("Toggle Object Visibility")
    tool_panel.CreateLabel("Objects")

    