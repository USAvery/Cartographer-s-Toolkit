## Uses Dungeondraft v1.1.0.0
##
## Scatter Plus v1.0.0
## Author: Avery Berg
## 
## Adds additional functionality to the scatter tool
##

# Required Global
var script_class = "tool"

# External Scripts
var utils = null
var preset_handler = null

# Globals
var scatter_tool = null
var group_item_list = null
var group_checkbox = null
var speed_slider = null
var group_ui_nodes = []

var on_icon = null
var off_icon = null
var scatter_group = []
var in_group_mode = false

var cur_texture = null

var time_since_random = 0.0

var prev_preset = null

var group_container = null


# ___________________Preset Functions___________________

func load_preset(name):
    ##
    ## Load a preset group
    ##
    print("Loading preset " + str(name))
    clear_group()
    if name == "Custom":
        preset_handler.name_input.set_text(" ")
        return
    
    var preset_data = preset_handler.get_preset_data(name)
    if not preset_data:
        return
    
    preset_handler.name_input.set_text(name)
    for resource_path in preset_data.get("resource_paths"):
        add_to_group(load(resource_path))
    
    randomize_asset(99.0)
    print("Loaded preset: " + name)


func save_preset():
    ##
    ## Callback function for clicking the save button
    ##
    preset_handler.save_preset(preset_handler.name_input.get_text(), scatter_group)



# ___________________Misc Functions___________________

func randomize_asset(delta):
    ##
    ## Select a random texture from the scatter group and
    ##   assign it to the scatter tool
    ##
    if scatter_group.size() == 0:
        return
    
    if speed_slider.get_value() == 0 and cur_texture:
        scatter_tool.Preview.Texture = cur_texture
        return
    
    var time_needed = (-0.221 * speed_slider.get_value()) + 2.22
    
    if cur_texture and time_needed > time_since_random:
        time_since_random += delta
        scatter_tool.Preview.Texture = cur_texture
        return
    
    var r_index : int = randi() % scatter_group.size()
    var random_tx = scatter_group[r_index]
    scatter_tool.Preview.Texture = random_tx
    cur_texture = random_tx
    time_since_random = delta


# ___________________Group Mode Functions___________________

func clear_group():
    ##
    ## Clear the scatter group
    ## Clear the group item list
    ##
    group_item_list.clear()
    scatter_group.clear()


func add_to_group(new_texture=null):
    ##
    ## Add the current preview texture to the scatter group
    ##
    if not new_texture:
        new_texture = scatter_tool.Preview.Texture
        if not new_texture:
            return 

    scatter_group.append(new_texture)
    group_item_list.add_icon_item(new_texture)


func set_group_mode(value):
    ##
    ## Set the group mode
    ## Set the group_checkbox button's icon to reflect the group mode
    ## Toggle the visibility of the group ui section
    ## Set or unset the scatter tool's texture
    ##
    in_group_mode = value

    # Set the group_checkbox icon
    # if in_group_mode:
    #     group_checkbox.icon = on_icon
    # else:
    #     group_checkbox.icon = off_icon
    
    # Toggle the visibility of the group ui section
    group_container.visible = in_group_mode
    
    # Set or unset the scatter tool's texture
    if in_group_mode:
        randomize_asset(99.0)
    if not in_group_mode:
        var obj_menu = Global.Editor.ObjectLibraryPanel.objectMenu
        scatter_tool.Preview.Texture = obj_menu.get_Selected()
    
    group_item_list.set_custom_minimum_size(Vector2(100, 100))


# ___________________Callback Functions___________________


func on_group_checkbox_click():
    ##
    ## Callback function for clicking the group checkbox button
    ##
    set_group_mode(!in_group_mode)
    

func on_select_group_item(index):
    print("Selected: " + str(index))
    scatter_tool.Preview.Texture = scatter_group[index]


func remove_group_item(index, position):
    print("Removing: " + str(index))

    scatter_group.remove(index)
    group_item_list.remove_item(index)

    randomize_asset(99.0)


# ___________________Base Functions___________________

func start():
    ##
    ## Initialize the mod
    ## Called immediately after the script is loaded
    ##

    # Load any external scripts
    utils = load(Global.Root + "scripts/utils.gd").new()
    preset_handler = load(Global.Root + "scripts/preset_handler.gd").new()

    # Initialize any external scripts
    utils.init(self)
    preset_handler.init(self)

    # Cache the scatter tool
    scatter_tool = Global.Editor.Tools["ScatterTool"]

    var tool_panel = Global.Editor.Toolset.GetToolPanel("ScatterTool")
    
    # Load the icons
    on_icon = utils.load_tx(Global.Root + "icons/on.png")
    off_icon = utils.load_tx(Global.Root + "icons/off.png")

    print("Adding the group container")

    # Create the group container
    group_container = utils.create_vbox()
    tool_panel.Align.add_child(group_container)
    tool_panel.Align.move_child(group_container, 0)

    print("Adding group checkbox button")

    # Create and add the "Group" checkbox button
    group_checkbox = utils.create_checkbutton("Group")
    group_checkbox.connect("pressed", self, "on_group_checkbox_click")
    tool_panel.Align.add_child(group_checkbox)
    tool_panel.Align.move_child(group_checkbox, 0)

    print("Adding preset dropdown")

    # Add preset dropdown to the tool panel
    var dropdown_box = preset_handler.preset_dropdown.get_parent()
    group_container.add_child(dropdown_box)

    print("Adding save box")

    # Add save box to the tool panel
    var save_box = preset_handler.name_input.get_parent()
    group_container.add_child(save_box)

    # Add connections to the preset dropdown and save button
    preset_handler.connect("changed_preset", self, "load_preset")
    preset_handler.save_button.connect("pressed", self, "save_preset")
    
    print("Creating the item list")

    # Add the group item list
    group_item_list = utils.create_item_list()
    group_item_list.set_allow_rmb_select(true)
    group_container.add_child(group_item_list)

    # Add connections to the group item list
    group_item_list.connect("item_selected", self, "on_select_group_item")
    group_item_list.connect("item_rmb_selected", self, "remove_group_item")

    print("Creating the clear hbox")

    # Create the add and clear hbox
    var hbox_b = utils.create_hbox()
    group_container.add_child(hbox_b)

    # Create and add the "Clear Group" button
    var clear_button = utils.create_button("Clear", Global.Root + "icons/trash.png")
    clear_button.set_tooltip("Clear Group")
    clear_button.set_h_size_flags(3)
    hbox_b.add_child(clear_button)

    # Add connections to the "Clear" button
    clear_button.connect("pressed", self, "clear_group")

    # Create and add the "Add" button
    var add_button = utils.create_button("Add", Global.Root + "icons/add.png")
    add_button.set_h_size_flags(3)
    add_button.set_tooltip("Add to Group")
    hbox_b.add_child(add_button)

    # Add connections to the "Add" button
    add_button.connect("pressed", self, "add_to_group")
    
    # Create the speed label
    var speed_label = utils.create_label(tool_panel, "Speed")
    tool_panel.Align.move_child(speed_label, 5)
    group_ui_nodes.append(speed_label)

    print("Creating the speed slider")

    # Create the speed slider
    speed_slider = utils.create_slider(tool_panel, 10.0, 0.0, 10.0, 1.0)
    tool_panel.Align.move_child(speed_slider.get_parent(), 6)
    group_ui_nodes.append(speed_slider.get_parent())

    print("Creating the separator")

    # Create the separator
    var sep = utils.create_separator(tool_panel)
    tool_panel.Align.move_child(sep, 2)

    print("Creating the spacer")

    # Add a spacer to the scatter tool's panel
    var spacer = utils.create_spacer(tool_panel, Vector2(0, 100))

    print("Setting the group mode")

    # Set the group mode to false and hide the group ui section
    set_group_mode(false)

    print("Finished startup")


func update(delta):
    ##
    ## Called once per tick
    ##
    var cur_focus = Global.Editor.Toolset.get_focus_owner()
    var cur_preset = get_selected_preset()
    
    if scatter_tool == Global.Editor.ActiveTool:
        if Input.is_mouse_button_pressed(BUTTON_LEFT) and not cur_focus:
            if in_group_mode:
                randomize_asset(delta)
    
    preset_handler.tick(delta)
        
