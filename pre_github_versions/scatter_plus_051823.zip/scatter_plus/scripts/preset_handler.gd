## Uses Dungeondraft v1.1.0.0
##
## Scatter Plus v1.0.0
## Author: Avery Berg
## 
## Adds additional functionality to the scatter tool
##

# Required Global
var script_class = "tool"
var _global = null
var preset_file_path = null

# External Scripts
var utils = null

# Globals

var on_icon = null
var off_icon = null

var preset_dropdown = null
var save_button = null

var presets_dict = {}

var prev_preset = null

signal "selected_preset"


# ___________________I/O Functions___________________

func load_presets_dict():
    ##
    ## Load the presets dictionary from the external json file
    ##

    # Open the file for reading
    var file = File.new()
    if file.open(preset_file_path, File.READ) != OK:
        print("Failed to open the presets file: " + preset_file_path)
        return false
    
    var file_text = file.get_as_text()
    
    # Load the JSON data from the file
    print("Parsing file data into a JSON")
    presets_dict = parse_json(file_text)

    if not presets_dict:
        presets_dict = {}

    # Close the file
    file.close()

    print("Loaded the ScatterPlus presets")
    
    # Refresh the preset dropdown
    refresh_preset_dropdown()

    return true


func save_preset(name, scatter_group):
    ##
    ## Save a new preset to the presets json
    ##

    # Create a preset
    var preset = create_preset(name, scatter_group)
    if not preset:
        return false
    
    # Remove the preset if it has no resource paths
    var do_remove_preset = not preset["resource_paths"]

    # Open the file for writing
    var file = File.new()
    if file.open(preset_file_path, File.WRITE) != OK:
        print("Failed to open presets file: " + preset_file_path)
        return false
    
    print("Opened the presets file")
    
    # Add the preset to the file data
    # Remove the preset from the file data if blank
    if do_remove_preset:
        presets_dict.erase(preset["name"])
    else:
        presets_dict[preset["name"]] = preset

    # Save the presets dictionary to the file
    file.store_string(to_json(presets_dict))

    # Close the file
    file.close()

    print("Saved the presets file")

    # Refresh the preset dropdown menu
    refresh_preset_dropdown()

    return true


func is_valid_preset_name(name):
    ##
    ## Determine if a preset name is valid
    ##
    var stripped_name = name.strip_edges(true, true)
    if stripped_name and stripped_name != "Custom":
        return true
    
    return false


func create_preset(name, scatter_group):
    ##
    ## Create a preset
    ##
    if not is_valid_preset_name(name):
        return null
        # name = name_input.get_text()
        # if not is_valid_preset_name(name):
        #     return null
    var preset = {
        "name": name,
        "resource_paths": []
    }

    # Populate the resource paths
    for scatter_item in scatter_group:
        preset["resource_paths"].append(scatter_item.resource_path)
    
    return preset


func load_needed_textures():
    ##
    ## Load in all textures used by saved presets
    ##
    print("Loading the needed textures for saved presets")

    var obj_menu = _global.Editor.ObjectLibraryPanel.objectMenu

    # Load in the textures used by saved presets
    var needed_resource_paths = []
    for preset_name in presets_dict.keys():
        for res_path in presets_dict[preset_name]["resource_paths"]:
            var menu_index = obj_menu.Lookup.get(res_path)
            obj_menu.OnItemSelected(menu_index)
    
    # Reset the object menu's selection
    # obj_menu.select(0, true)
    obj_menu.OnItemSelected(0)


func get_preset_data(name):
    ##
    ## Get the data needed for a preset
    ##
    if name == "Custom":
        return null
    
    return presets_dict.get(name)


func get_selected_preset():
    ##
    ## Get the name of the selected preset
    ##
    var index = preset_dropdown.get_selected_id()

    if index < preset_dropdown.get_item_count():
        return preset_dropdown.get_item_text(index)
    else:
        print("Index out of range.")
        return ""


func in_custom_preset_mode():
    if get_selected_preset() == "Custom":
        return true
    return false


func refresh_preset_dropdown():
    print("Refreshing ScatterPlus preset dropdown")
    
    preset_dropdown.clear()
    preset_dropdown.add_item("Custom")

    for key in presets_dict.keys():
        preset_dropdown.add_item(key)
    
    print("Finishing refreshing dropdown")


func tick(delta):
    ##
    ## Called once per tick
    ##
    if scatter_tool == Global.Editor.ActiveTool:
        var cur_preset = get_selected_preset()

        if cur_preset != prev_preset:
            selected_preset.emit(cur_preset)
        
        prev_preset = cur_preset


func init(caller):
    _global = caller.Global
    preset_file_path = _global.Root + "data/presets.json"

