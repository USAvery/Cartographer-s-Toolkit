## Uses Dungeondraft v1.1.0.0
##
## Scatter Plus v1.0.0
## Author: Avery Berg
## 
## Adds additional functionality to the scatter tool
##

# Required Global
var script_class = "tool"

# External Scripts
var utils = null

# Globals
var scatter_tool = null
var group_item_list = null
var group_checkbox = null
var speed_slider = null
var group_ui_nodes = []

var on_icon = null
var off_icon = null
var scatter_group = []
var in_group_mode = false

var cur_texture = null

var time_since_random = 0.0

var preset_dropdown = null
var custom_preset_nodes = []
var save_button = null
var name_input = null
var presets_dict = {}

var prev_preset = null


# ___________________Preset Functions___________________

func load_presets_dict():
    var file = File.new()
    var file_path = self.Global.Root + "data/presets.json"

    # Open the file in read-write mode
    if file.open(file_path, File.READ_WRITE) == OK:
        var file_text = file.get_as_text()

        if file_text == "":
            print("File is empty: " + file_path)
            return false
        
        print("Parsing file data into a JSON")

        # Load the JSON data from the file
        presets_dict = parse_json(file_text)

        if not presets_dict:
            presets_dict = {}

        # Close the file
        file.close()

        print("Loaded the ScatterPlus presets")
        
        refresh_preset_dropdown()

        return true
    
    print("Failed to load the ScatterPlus presets")
    return false


func is_valid_preset_name(name):
    var stripped_name = name.strip_edges(true, true)
    if stripped_name and stripped_name != "Custom":
        return true
    
    return false


func create_preset(name=null):
    if not name:
        name = name_input.get_text()
        if not is_valid_preset_name(name):
            return null
    var preset = {
        "name": name,
        "resource_paths": []
    }
    for scatter_item in scatter_group:
        preset["resource_paths"].append(scatter_item.resource_path)
    return preset


func save_preset(preset=null):
    var file = File.new()
    var file_path = self.Global.Root + "data/presets.json"

    # Create a preset (if not provided)
    if not preset:
        preset = create_preset()
        if not preset:
            return
    var preset_name = preset["name"]

    var remove_preset = false
    if not preset["resource_paths"]:
        remove_preset = true

    # Open the file in read-write mode
    if file.open(file_path, File.READ_WRITE) == OK:
        print("Opened the file")

        var file_text = file.get_as_text()

        if file_text == "":
            print("File is empty: " + file_path)
            return false
        
        # Load the JSON data from the file
        presets_dict = parse_json(file_text)
        
        # Add the preset to the file data
        presets_dict[preset_name] = preset

        # Remove the preset from the data if blank
        presets_dict.erase(preset_name)

        # Save the preset to the file
        file.store_string(to_json(presets_dict))

        # Close the file
        file.close()

        print("Closed the file")

        refresh_preset_dropdown()

        return true
    else:
        print("Failed to open file: " + file_path)
        return false


func get_pack_id_from_res_path(res_path):
    ##
    ## Get the id of an asset pack from an object's resource path
    ##
    var split_path = res_path.split(':')[-1].right(2).split('/')
    if not split_path.size() or split_path[0] != "packs":
        return null
    
    return split_path[1]


func get_asset_pack_name_from_id(pack_id):
    ##
    ## Get the name of an asset pack from it's id
    ##
    for asset_pack in Global.Header.get_AssetManifest():
        if asset_pack.get_ID() == pack_id:
            return asset_pack.get_Name()
    
    return null


func load_needed_textures():
    ##
    ## Load in all textures used by saved presets
    ##
    print("Loading the needed textures for saved presets")

    var obj_menu = Global.Editor.ObjectLibraryPanel.objectMenu

    # Load in the textures used by saved presets
    var needed_resource_paths = []
    for preset_name in presets_dict.keys():
        for res_path in presets_dict[preset_name]["resource_paths"]:
            var menu_index = obj_menu.Lookup.get(res_path)
            obj_menu.OnItemSelected(menu_index)
            
    
    # Reset the object menu's selection
    # obj_menu.select(0, true)
    obj_menu.OnItemSelected(0)


func load_preset(name):
    clear_group()
    if name == "Custom":
        name_input.set_text(" ")
        return
    
    name_input.set_text(name)
    for resource_path in presets_dict[name]["resource_paths"]:
        var new_tx = load(resource_path)
        add_to_group(new_tx)
    
    randomize_asset(99.0)
    print("Loaded preset: " + name)


func get_selected_preset():
    var index = preset_dropdown.get_selected_id()

    if index < preset_dropdown.get_item_count():
        return preset_dropdown.get_item_text(index)
    else:
        print("Index out of range.")
        return ""


func in_custom_preset_mode():
    if get_selected_preset() == "Custom":
        return true
    return false


func refresh_preset_dropdown():
    print("REFRESHING")
    preset_dropdown.clear()
    preset_dropdown.add_item("Custom")
    print("Cleared dropdown")
    print("Presets dictionary: " + str(presets_dict))
    for key in presets_dict.keys():
        preset_dropdown.add_item(key)
    print("Finishing refreshing dropdown")


# ___________________Misc Functions___________________

func randomize_asset(delta):
    ##
    ## Select a random texture from the scatter group and
    ##   assign it to the scatter tool
    ##
    if scatter_group.size() == 0:
        return
    
    if speed_slider.get_value() == 0 and cur_texture:
        scatter_tool.Preview.Texture = cur_texture
        return
    
    var time_needed = (-0.221 * speed_slider.get_value()) + 2.22
    
    if cur_texture and time_needed > time_since_random:
        time_since_random += delta
        scatter_tool.Preview.Texture = cur_texture
        return
    
    var r_index : int = randi() % scatter_group.size()
    var random_tx = scatter_group[r_index]
    scatter_tool.Preview.Texture = random_tx
    cur_texture = random_tx
    time_since_random = delta


# ___________________Group Mode Functions___________________

func clear_group():
    ##
    ## Clear the scatter group
    ## Clear the group item list
    ##
    group_item_list.clear()
    scatter_group.clear()


func add_to_group(new_texture=null):
    ##
    ## Add the current preview texture to the scatter group
    ##
    if not new_texture:
        new_texture = scatter_tool.Preview.Texture
        if not new_texture:
            return 

    scatter_group.append(new_texture)
    group_item_list.add_icon_item(new_texture)


func set_group_mode(value):
    ##
    ## Set the group mode
    ## Set the group_checkbox button's icon to reflect the group mode
    ## Toggle the visibility of the group ui section
    ## Set or unset the scatter tool's texture
    ##
    in_group_mode = value

    # Set the group_checkbox icon
    if in_group_mode:
        group_checkbox.icon = on_icon
    else:
        group_checkbox.icon = off_icon
    
    # Toggle the visibility of the group ui section
    for ui_node in group_ui_nodes:
        if ui_node is OptionButton:
            ui_node.get_parent().visible = in_group_mode
        ui_node.visible = in_group_mode
    
    # Set or unset the scatter tool's texture
    if in_group_mode:
        randomize_asset(99.0)
    if not in_group_mode:
        var obj_menu = Global.Editor.ObjectLibraryPanel.objectMenu
        scatter_tool.Preview.Texture = obj_menu.get_Selected()
    
    group_item_list.set_custom_minimum_size(Vector2(100, 100))


# ___________________Callback Functions___________________

func on_select_preset_target(index):
    print("HELLO WORLD!")
    # load_preset(get_selected_preset())


func on_group_checkbox_click():
    ##
    ## Callback function for clicking the group checkbox button
    ##
    set_group_mode(!in_group_mode)


func on_select_group_item(index):
    print("Selected: " + str(index))
    scatter_tool.Preview.Texture = scatter_group[index]


func remove_group_item(index, position):
    print("Removing: " + str(index))

    scatter_group.remove(index)
    group_item_list.remove_item(index)

    randomize_asset(99.0)


func start():
    ##
    ## Initialize the mod
    ## Called immediately after the script is loaded
    ##

    # Load any external scripts
    utils = load(Global.Root + "scripts/utils.gd").new()

    # Cache the scatter tool to make it easier to reference in this script
    scatter_tool = Global.Editor.Tools["ScatterTool"]

    var tool_panel = Global.Editor.Toolset.GetToolPanel("ScatterTool")
    # var panel_length = tool_panel.get_children()[-1].get_children().size()
    on_icon = utils.load_tx(Global.Root + "icons/on.png")
    off_icon = utils.load_tx(Global.Root + "icons/off.png")

    # Create and add the "Group" checkbox button
    group_checkbox = tool_panel.CreateButton("Group", Global.Root + "icons/off.png")
    group_checkbox.connect("pressed", self, "on_group_checkbox_click")
    tool_panel.Align.move_child(group_checkbox, 0)

    # Create the "Preset" dropdown menu
    preset_dropdown = tool_panel.CreateLabeledDropdownMenu("on_select_preset_target", "Preset", ["Custom"], "Custom")
    tool_panel.Align.move_child(tool_panel.get_children()[-1].get_children()[-1], 1)
    group_ui_nodes.append(preset_dropdown)

    # Create the hbox
    var hbox = utils.create_hbox(tool_panel)
    tool_panel.Align.move_child(hbox, 2)
    group_ui_nodes.append(hbox)

    # Add the group label
    var group_label = Label.new()
    group_label.set_text("Name")
    hbox.add_child(group_label)

    # Create the "Name" line edit
    name_input = LineEdit.new()
    name_input.set_custom_minimum_size(Vector2(145, 5))
    hbox.add_child(name_input)

    # Create and add the "Save Preset" button
    save_button = Button.new()
    save_button.set_tooltip("Save as Preset")
    save_button.icon = utils.load_tx(Global.Root + "icons/save.png")
    save_button.connect("pressed", self, "save_preset")
    hbox.add_child(save_button)

    # Add the group item list
    group_item_list = utils.create_item_list(tool_panel)
    group_item_list.set_allow_rmb_select(true)
    group_item_list.connect("item_selected", self, "on_select_group_item")
    group_item_list.connect("item_rmb_selected", self, "remove_group_item")
    tool_panel.Align.move_child(group_item_list, 3)
    group_ui_nodes.append(group_item_list)

    # Create the add and clear hbox
    var hbox_b = utils.create_hbox(tool_panel)
    hbox_b.set_h_size_flags(3)
    tool_panel.Align.move_child(hbox_b, 4)
    group_ui_nodes.append(hbox_b)

    # Create and add the "Clear Group" button
    var clear_button = Button.new()
    clear_button.text = "Clear"
    clear_button.set_tooltip("Clear Group")
    clear_button.icon = utils.load_tx(Global.Root + "icons/trash.png")
    clear_button.connect("pressed", self, "clear_group")
    clear_button.set_h_size_flags(3)
    hbox_b.add_child(clear_button)

    # Create and add the "Add to Group" button
    var add_button = Button.new()
    add_button.text = "Add"
    add_button.set_tooltip("Add to Group")
    add_button.icon = utils.load_tx(Global.Root + "icons/add.png")
    add_button.connect("pressed", self, "add_to_group")
    add_button.set_h_size_flags(3)
    hbox_b.add_child(add_button)
    
    # Create the speed label
    var speed_label = utils.create_label(tool_panel, "Speed")
    tool_panel.Align.move_child(speed_label, 5)
    group_ui_nodes.append(speed_label)

    # Create the speed slider
    speed_slider = utils.create_slider(tool_panel, 10.0, 0.0, 10.0, 1.0)
    tool_panel.Align.move_child(speed_slider.get_parent(), 6)
    group_ui_nodes.append(speed_slider.get_parent())

    # Create the separator
    var sep = utils.create_separator(tool_panel)
    tool_panel.Align.move_child(sep, 7)

    # Add a spacer to the scatter tool's panel
    var spacer = utils.create_spacer(tool_panel, Vector2(0, 100))

    # Set the group mode to false and hide the group ui section
    set_group_mode(false)

    # Load the presets
    load_presets_dict()

    prev_preset = get_selected_preset()

    # Load the needed textures
    load_needed_textures()

    print("Finished startup")


func update(delta):
    ##
    ## Called once per tick
    ##
    var cur_focus = Global.Editor.Toolset.get_focus_owner()
    var cur_preset = get_selected_preset()
    
    if scatter_tool == Global.Editor.ActiveTool:
        if Input.is_mouse_button_pressed(BUTTON_LEFT) and not cur_focus:
            if in_group_mode:
                randomize_asset(delta)
        
        if cur_preset != prev_preset:
            load_preset(cur_preset)
        
        prev_preset = cur_preset
